from colorama import init
from colorama import Fore, Back, Style

# case #1 : using 'global key'
s = 1
def print1():
    print("from print1 s = ", s)

def print2():
    s = s + 10 # s can be accessed for reading but not writing in a local function
    print("from print2 s = ", s)

def print3():
    global s # fix: use global keyword to indicate "i am accessing a global variable"
    s = s + 10
    print("from print3 s = ", s)

print1() # print "global" s
print2() # Error!
print3() # fixing the error from print2()


# case #2: using 'non_local' in a nested function
s = 1 
def print1():
    s = 100
    print("from print1 s = ", s)
    def print2():
        #global s (if you have to access the global)
        #nonlocal s (if you have to access the s defined one level outside)
        #s = s + 10 # without the specifier, s cannot be accessed for writing in a local function but only writing
                    # without the specifier, s will only be read only Local->Enclosing->Global->Built-in
        print("from print2 s = ", s)
    print2()

# call the print1()    
print1() 


'''
s = 0
def print1():     
    print(Fore.LIGHTYELLOW_EX + "print1-A---: %03d at %d" %(s, id(s)))
    def print2():
        print(Fore.GREEN + "print2----------: %d at %d" %(s, id(s)))
        return
    print2()
    print(Fore.LIGHTYELLOW_EX + "print1-B---: %03d at %d" %(s, id(s)))
    return
# init for colorama module
init() 

# main starts
print(Fore.RED + "main-A:   %03d at %d" %(s, id(s)))
print1()
print(Fore.RED + "main-B:   %03d at %d" %(s, id(s)))
'''

#
# How about storing a first character of each string to a list?
# def print1st(strings):
#     ''' print1st returns a list with first character of each string
#         stroed in the input list, 'strings' '''
#     # output: str_ = ['H']
#     out=[]
#     for s in strings:
#         if s[0].isupper():
#             out.append(s[0])
#     return out

# strings = ["How", "are", "you", "today", "John?", "123", " ", ""]
# print1st(strings)