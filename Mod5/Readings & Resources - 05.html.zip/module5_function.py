
# -- function definition
#  Function DEFINITION 
# def function_name(parameters):
#     ''' doc string or help(function_name), function_name.__doc__ '''
#     statements
#     return something
#

# -- function definition without args, and return statements
def function1():
    ''' Function Name: function1()
        Argument: None
        Return Value: None
        Summary: Prints a greeting message '''
    name = "Harry"
    print("Hello, ", name, "! Good morning!")

def function2():
    ''' Function Name: function1()
        Argument: None
        Return Value: None        
        Summary: Prints a greeting message '''
    name = "Sally"
    print("Hello, ", name, "! Good morning!")

function1()
function2()

# -- function definition with arguments
# this function prints the name + message inside the function greeting
def greeting (name):
    print("Hello, " + name + "! Good morning!")

name = input("What is your name? ")
greeting(name)

# -- MORE on function arguments
#    how about passing the message and name to be more flexible
def greeting3 (name, msg):
   print("Hello, " + msg + "! " + name)

name = input("What is your name? ")
msg = input("Enter the greeting message ")
greeting3(name, msg) # try without msg and explain the error message

# -- MORE on function arguments
#    how about passing the message and name to be more flexible
# now using a return statement
def greeting3 (name, msg):
    retStr = "Hello, " + msg + "! " + name
    return retStr
name = input("What is your name? ")
msg = input("Enter the greeting message ")
greeting_msg = greeting3(name, msg) # try without msg and explain the error message
print(greeting_msg)



#
# -- can we pass a list to a function?
#    I have a list of people and would like to greet individually with message.
def greeting_my_friends(friends_list, msg):
    for f in friends_list:
        print(msg + " " + f + "!")

friends1 = ("Jason", "Brenna", "Shannon")
friends2 = ["Jason", "Brenna", "Shannon"]

msg = input("Enter the greeting message ")
greeting_my_friends(friends1, msg)
greeting_my_friends(friends2, msg)

#
def addnum(x):
    sum = 0
    for i in range(len(x)):
        sum += x[i]
    return sum
value = [1, 10, 100]
sum = addnum(value)
print("total sum = ", sum)

#
def addnum(x, y, *_):# def addnumbs(x, y, *_): [1, 10, 100] 100 being ignored
    return x + y
value = [1, 10, 100]
sum = addnum(*value)
print("total sum = ", sum)

#
# passing a dictionary
def addnum(d):     
    s = 0
    print(d)
    for k, v in d.items():
        print(k, " ", v)
        s = s + v
    return s
d = {'a': 1, 'b': 2}
s = addnum(d)
print(s)

#
# Python program to find the common elements in two lists 
#
def common_member(a, b): 
    a_set = set(a) 
    b_set = set(b) 
  
    if (a_set & b_set): 
        print(a_set & b_set) 
    else: 
        print("No common elements")  

   
a = [1, 2, 3, 4, 5] 
b = [5, 6, 7, 8, 9] 
common_member(a, b) 

a = [1, 2, 3, 4, 5] 
b = [6, 7, 8, 9] 
common_member(a, b) 

#
# function that returns multiple values in tuple
#
def funct1():
    myStr = "My Zip Code"
    myZip = "98011"
    return myStr, myZip  # Return as tuple
    
label, zip = funct1() # store the return values in tuple
print(label)
print(zip)

# function that returns multiple values in list
def funct1():
    myStr = "My Zip Code"
    myZip = "98011"
    return [myStr, myZip]  # Return as list
    
retList = funct1() # store the return values in list
print(retList)

# function that returns multiple values in dict
def funct1():
    myInfo = dict()
    myInfo['Label']   = "My Zip Code"
    myInfo['ZipCode'] = "98011"
    return myInfo  # Return as dict
    
myInfo = funct1() # store the return values in dict
print(myInfo)

# #
# # -- how about passing a dictionary to a function?
def greeting_my_friends2(friends_dict):
    for key in friends_dict:
        print(friends_dict[key], " " + key + "!") # key 
# d = {key: value} == {'name':'message'}
friends_greeting = {'Jason':'Good morning', 'Brenna':"I miss you", 'Shannon':"How have you been sis!"}

# -- let's look at Scope of Variables
# Global variable is visible and modifiable (read/write-able)
# Local variables is only visible inside the function block (R/W-able)
# Local variables cannot be used in the global scope.
# Global variable can be used inside the function by using "global" keyword

# let's look at the following example

v = 1 # global var.
def add_print_X():
    print(v) # global var is visible(Read) in local function

def add_print_X():
    x = 10 # x is a local var inside add_print_X()
    print(x)

# once you are outside the add_print_X(), Python doesn't know what 'x' is.
# x is only visible in the block where it is defined only in the add_print_X function.
print(x) # error!



# let's make it more complicated
# what if I have the same variable name being used between global and local.
# we now have conflict in variable scope!

v = 1 # global var.
def add_print_X():
    print(v) # reading is fine
    # when you do 'v = ', you're declaring a new var, but they already know
    # v is in the global var list. Therefore, Python only allows you to read, but
    # not overwrite.
    # v can be accessed for reading but not writing in a local function
    v = v + 10 # error!
    print(v)

def add_print_O():
    # fix: use global keyword to indicate "i am accessing THAT global variable" explicitly
    global v 
    v = v + 10 # fixed!
    print(v)

add_print_O()
add_print_X()


# This example will throw an error UnboundedError
# It gives us the error because "name" in greeting2 isn't defined yet
# at the time of assignment therefore it doesn't know where to 
# store (cannot assign!). Define a variable before store!
#
# UnboundLocalError: local variable 'name' referenced before assignment
#----------------------------------------------------
def greeting ():
    name = "Hello, " + name + "! Good morning!"
    return name

print("What is your name? ")
# this name is global
name = input()
print(greeting())
#----------------------------------------------------
#Fix1 (create a new local var.)
def greeting ():
    message = "Hello, " + name + "! Good morning!"
    return message

print("What is your name? ")
name = input()
print(greeting())
#----------------------------------------------------
#Fix2 (passing the argument)-------------------------
def greeting (name):
    name = "Hello, " + name + "! Good morning!"
    return name

print("What is your name? ")
# this name is global
name = input()
print(greeting(name))

# But, what if you want to maintain only one global variable since
# you might use it later in your code.
#---------------------------------------------------
#Fix3 (then use global)-- use global key to modify
# This means, ok look for name outside of greeting2() and if you find one
# use that to store.
def greeting ():
    global name # look for name outside of this function greeting() scope
    name = "Hello, " + name + "! Good morning!"
    return name

print("What is your name? ")
name = input()
print(greeting())
#---------------------------------------------------


#Global v Nonlocal----------------------------------
name = "Harry" # remove when nonlocal
def greeting2(name):
    name = "Hello, " + name + "! Good morning!"
    print("greeting2-A = " + str(hex(id(name))))

    def greeting3():
        # global name # this will print the same address as name (global)
        nonlocal name # this will fix the problem of getting outside of local scope telling that "name is not defined in the local scope and to keep search outwards"
                      # Since the assignment limits the search for x to the local scope, it can't be found and I get the error.
        print(name) # when I do this, I access via Local scope(first) -> Enclosing scope(second) -> Global(third) -> Built-in(last)
        # therefore this 'name' is enclosed name defined in greeting2()
        name = name.upper() # new object at a new address
        print(name)
        print("greeting3 = " + str(hex(id(name))))
        return name
    
    print(greeting3())
    print("greeting2-B = " + str(hex(id(name))))
    return name

print("What is your name? ")
name = input()
print("main-A = " + str(hex(id(name))))
print(greeting2(name))
print("main-B = " + str(hex(id(name))))
print(name)


# -- what is wrong with the following code and how would you fix
#   UnboundedLocalError?
# Note that the assignment limits the search for x to the local scope, it can't be found and I get the error.
def foo():
    x = 23
    def goo():
        # the reason why we are getting this error is 
        # self modifying operation such as += which means READ/WRITE operations at the same time
        x = x + 1 # fix via nonlocal. nonlocal / global are exclusive
        return x
    return goo()
print(foo())

#
# -- another example of using variable at a different scope
#
# name = "Harry" # this is a global variable
# def name_change():
    #    global name    accessing the global var
    # name = "Sally"
    # print("inside name_change(): ", name) # Sally (from local)

# name_change()
# print("outside name_change(): ", name) # Harry (from global)
name = "Johnson" # this is a global variable
def function1():
    name = "Harry"
    def function2():
        # nonlocal name #(follow the block)
        name = "Sally"
        print("Function2: ", name)
    function2()
    print("Function1:", name)

print("Outside Before:", name)
function1()
print("Outside After:", name)

'''
#1
c:\CityU\CS160\M1>test.py --> without nonlocal name in function2()
Outside Before: Johnson
Function2:  Sally
Function1: Harry
Outside After: Johnson
'''
'''
#2
c:\CityU\CS160\M1>test.py --> with nonlocal name in function2()
Outside Before: Johnson
Function2:  Sally
Function1: Sally <-- * name modified in function1() ie. Harry is replaced by ="Sally" assignment
Outside After: Johnson
'''

'''-------------------- OPTIONAL (built-in) try to avoid using builtin names ----------------------'''
'''
x = 'global x'
def foo():
    # y = 'local y'
    # global x
    x = 'local x'
    print (x)
foo()
print(x)
'''

'''
def test(z):
    x = 'local x'
    print(z)

test('local z') # try z out of scope
'''
''' built-in (min vs min(list))
# import builtins
# print(dir(builtins))

 def my_min():
    pass

m = min([5, 2, 1, 3])
print (m)
'''
'''
def outer():
    x = 'outer x'
    def inner():
        #nonlocal x # only available in the nest function blocks
        x = 'inner x' 
        print(x)
    inner()
    print(x)
outer()    
'''

''' (summary)
x = 'global x'
def outer():
    x = 'outer x'
    def inner():
        x = 'inner x' 
        print(x)
    inner()
    print(x)
outer()    
print(x)
'''


def greeting3 (name, msg = "Good Morning!"): # default argument
   print("Hello, " + name + "! " + msg)

print("What is your name? ")
name = input()
print("Enter the greeting message ")
msg = input()
if len(msg) == 0:
    greeting3(name)
else:
    greeting3(name, msg) 


def compute_area(*dim): 
    result = 0
    if (len(dim) == 1): # x and pi for 2D circle
        result = 3.14 * dim[0] ** 2
    elif (len(dim) == 2): # x, y for 2D rect
        result = dim[0] * dim[1]
    elif (len(dim) == 3): # x, y, z for 3D volumn
        result = dim[0] * dim[1] * dim[2]
    else:
        print("invalid input params")
    return result

result = compute_area(2)
print("result is ", result)
result = compute_area(3, 2)
print("result is ", result)
result = compute_area(3, 2, 9.2)
print("result is ", result)
i = [2,3]
result = compute_area(*i)
print("result is ", result)

#
# using kwargs
#

def compute_area_new(**kwargs): 
    print(kwargs)
    ret = 0
    
    if len(kwargs) == 1:
        ret = kwargs['radius'] ** 2 * 3.14
    elif len(kwargs) == 2:
        ret = kwargs['width'] * kwargs['width']
    elif len(kwargs) == 3:
        ret = kwargs['width'] * kwargs['width'] * kwargs['length']
    return ret


result = compute_area_new(width = 2, height = 3, length = 2)
print(result)
result = compute_area_new(radius = 3)
print(result)












''' Exception handling 
def division(divisor):
    return 100/divisor
'''
def division(divisor):
    try:
        return 100/divisor
    except ZeroDivisionError:
        print('Error: Invalid Argument.')
        # return -1

print(division(10))
print(division(0)) 
print(division(50))


# Generator is very close to list comprehension
# Generator expression


