#
# '''How about storing a first character of each string to a list?'''
# HOW WOULD YOU DEBUG?
def print1st(strings):
    ''' print1st returns a list with first character of each string
        stroed in the input list, 'strings' '''
    # output: str_ = ['H']
    out=[]
    for s in strings:
        if s[0].isupper():
            out.append(s[0])
    return out

strings = ["How", "are", "you", "today", "John?", "123", ""]
caps = print1st(strings)
print(caps)

#
# '''How about storing a first character of each string to a list?'''
# CORRECT SOLUTION
def print1st(strings):
    ''' print1st returns a list with first character of each string
        stroed in the input list, 'strings' '''
    # output: str_ = ['H']
    out=[]
    for s in strings:
        if len(s) > 0:
          if s[0].isupper():
            out.append(s[0])
    return out

strings = ["How", "are", "you", "today", "John?", "123", ""]
caps = print1st(strings)
print(caps)


 